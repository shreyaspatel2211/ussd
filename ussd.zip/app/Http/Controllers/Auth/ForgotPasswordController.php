<?php

namespace App\Http\Controllers\Auth;

use Wave\Http\Controllers\Auth\ForgotPasswordController as AuthForgotPasswordController;

class ForgotPasswordController extends AuthForgotPasswordController
{

}
