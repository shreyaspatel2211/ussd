<?php

namespace App\Http\Controllers\Auth;

use Wave\Http\Controllers\Auth\ResetPasswordController as AuthResetPasswordController;

class ResetPasswordController extends AuthResetPasswordController
{

}
