# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY.**

## Reporting a Vulnerability

If you discover a security vulnerability within Laravel Wave, please send an email to the DevDojo team at support@devdojo.com. All security vulnerabilities will be promptly addressed.
